<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DetalleVentaController extends Controller
{
    //
}
