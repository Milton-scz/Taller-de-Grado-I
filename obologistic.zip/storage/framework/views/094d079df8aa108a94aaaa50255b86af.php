<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Envío de Paquetes - Find</title>
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet"/>
    <!-- Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">

</head>
<body class="bg-gray-100 dark:bg-gray-600 justify-between">


    <!-- Navbar -->
    <?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /Navbar -->


<div class="max-w-md mx-auto mt-10 p-6 bg-gray-800 rounded-xl shadow-lg mb-10">
    <!-- Date Section -->
    <div class="flex items-center justify-between">
        <div>

            <div class="text-5xl font-bold text-white">
                <?php
                 $timestamp = strtotime($guia->fecha_salida);
                 $dia = date('d', $timestamp);
                 echo $dia;
                ?>
                </div>
            <div class="text-xl uppercase text-white">
            <?php
                 $timestamp = strtotime($guia->fecha_salida);
                 $nombre_dia = date('l', $timestamp);
                 echo $nombre_dia;
                ?>
            </div>
            <div class="uppercase tracking-wide text-white">
            <?php
                 $timestamp = strtotime($guia->fecha_salida);
                 $nombre_mes = date('F', $timestamp);
                 $nombre_mes = ucfirst($nombre_mes);
                 echo $nombre_mes;
                ?>
            </div>
        </div>
        <div class="text-green-500 font-semibold text-2xl">Delivered</div>
    </div>

    <!-- Tracking Information -->
    <div class="mt-4 relative">
    <div class="absolute h-full border-l-2 border-gray-600 left-3 top-2.5"></div>
        <?php $__currentLoopData = $guia->ruta_rastreo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ruta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if (isset($component)) { $__componentOriginal25d21f96227944e594071020bfc8f335 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal25d21f96227944e594071020bfc8f335 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ruta-rastreo-card','data' => ['ruta' => $ruta]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ruta-rastreo-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['ruta' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($ruta)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal25d21f96227944e594071020bfc8f335)): ?>
<?php $attributes = $__attributesOriginal25d21f96227944e594071020bfc8f335; ?>
<?php unset($__attributesOriginal25d21f96227944e594071020bfc8f335); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal25d21f96227944e594071020bfc8f335)): ?>
<?php $component = $__componentOriginal25d21f96227944e594071020bfc8f335; ?>
<?php unset($__componentOriginal25d21f96227944e594071020bfc8f335); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Additional Information -->
    <div class="mt-4">
        <a href="#" class="text-blue-500 block">Track the Status on [OBOLOGISTIC]</a>
        <div class="mt-2">
            <div class="text-sm text-white">Destination</div>
            <div class="text-sm text-green-500"><?php echo e($guia->almacenLlegada->nombre); ?></div>
        </div>
        <div class="mt-2 text-white">
            <div class="text-sm ">MMCA</div>
            <div class="text-lg text-green-500"><?php echo e($guia->codigo); ?></div>
        </div>
        <div class="mt-4">
            <a href="#" class="text-blue-500">Obologistic.com</a>
        </div>
    </div>
</div>

</body>
</html>
<?php /**PATH D:\CARRERA INGENIERIA EN INFORMATICA\TALLER DE GRADO I\obologistic\resources\views/GestionarGuias/guias/find.blade.php ENDPATH**/ ?>