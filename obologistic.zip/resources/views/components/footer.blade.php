<footer class="p-2 md:p-4 rounded-lg shadow bg-gray-800">
    <div class="sm:flex sm:items-center sm:justify-between">

    </div>
    <hr class="my-4 border-gray-700 lg:my-6" />
    <span class="block text-sm sm:text-center text-gray-400">&copy; 2023 <a href="https://Obologistic.com" target="_blank" class="hover:underline">Obologistic™</a>. All Rights Reserved.</span>
</footer>


        <!-- /Footer -->
